﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sheet_02_Q1
{
    internal class books
    {
        public String Title;
        public String Author;
    }
}
