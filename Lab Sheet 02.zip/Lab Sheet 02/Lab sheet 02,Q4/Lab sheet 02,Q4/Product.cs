﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sheet_02_Q4
{
    internal class Product
    {
        public string ProductName;
        public double Price;

        public Product(string productName, double price)
        {
            ProductName = productName;
            Price = price;
        }
    }
}
