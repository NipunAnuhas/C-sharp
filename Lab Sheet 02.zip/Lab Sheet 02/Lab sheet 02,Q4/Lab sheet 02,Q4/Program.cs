﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sheet_02_Q4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product product = new Product("Smart Phone", 12000.00);

            ProductDetails(product);
            Console.ReadLine();
        }


         static void ProductDetails(Product product)
        {
            Console.WriteLine("Product Details: ");
            Console.WriteLine($"Product Name: {product.ProductName}");
            Console.WriteLine($"Price: ${product.Price}");
            Console.WriteLine();
        }
    }
}