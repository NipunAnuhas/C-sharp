﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sheet_02_Q5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LibraryBook[] books = new LibraryBook[3];

            books[0] = new LibraryBook("Book 1", "author 1", true);
            books[0] = new LibraryBook("Book 2", "author 2", false);
            books[0] = new LibraryBook("Book 3", "author 3", true);

            Console.WriteLine("Initial library status;");
            DisplayLibraryStatus(books);

            Console.WriteLine("\n");
            books[0].BorrowBook();
            books[1].BorrowBook();
            books[2].BorrowBook();

            Console.WriteLine("\n\nUpdated library status:");
            DisplayLibraryStatus(books);
            Console.ReadLine();
        }
        static void DisplayLibraryStatus(LibraryBook[] books)
        { foreach (var book in books)
            {
                Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, Available: {(book.Available ? "Yes" : "No")}");
            }
        }

    }
}
