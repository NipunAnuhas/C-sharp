﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sheet_02_Q5
{
    internal class LibraryBook
    {

        public string Title;
        public string Author;
        public bool Available;

        public LibraryBook(string title, string auther, bool available)

        {
            Title = title;
            Author = auther;
            Available = available;

        }
        public void BorrowBook()

        {
            if (Available)
            {
                Available = false;
                Console.WriteLine($"You have borrowed '{Title}' by {Author}. ");

            }
        }

    }
}
